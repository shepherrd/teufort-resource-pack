Teufort Weapons private resource pack.
Use with TeufortWeapons-datapack on Minecraft Java 26.2.
This pack contains only the Teufort weapon compatibility layer.